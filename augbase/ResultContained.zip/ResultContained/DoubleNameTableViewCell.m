//
//  DoubleNameTableViewCell.m
//  ResultContained
//
//  Created by 李胜书 on 15/6/29.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import "DoubleNameTableViewCell.h"

@implementation DoubleNameTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
