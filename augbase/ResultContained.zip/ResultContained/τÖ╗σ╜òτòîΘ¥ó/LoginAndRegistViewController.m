//
//  LoginAndRegistViewController.m
//  ResultContained
//
//  Created by 李胜书 on 15/6/30.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import "LoginAndRegistViewController.h"

@interface LoginAndRegistViewController ()


@end

@implementation LoginAndRegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    _phoneNumber.frame = CGRectMake(0,0,250, 40);
    
    //去登陆界面
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(0,2, 30, 30)];
    
    //button1.center = CGPointMake(160, 200);
    loginButton.titleLabel.font = [UIFont boldSystemFontOfSize:22];
    [loginButton setImage:[UIImage imageNamed:@"test"] forState:UIControlStateNormal];
    
    //button1.displayShading = YES;
    
    [loginButton addTarget:self action:@selector(loginView) forControlEvents:UIControlEventTouchUpInside];
    
    [self.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithCustomView:loginButton]];
    
}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    [_phoneNumber becomeFirstResponder];
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
}

-(void)loginView
{
//    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    UIViewController *lgv = [story instantiateViewControllerWithIdentifier:@"loginview"];
//    [self.navigationController pushViewController:lgv animated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)confirmPhonenumber:(id)sender
{
    if ([self isValidateMobile:_phoneNumber.text]) {
        NSLog(@"手机号码通过验证");
        UIButton *nextButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
        [nextButton setImage:[UIImage imageNamed:@"goin_w"] forState:UIControlStateNormal];
        [nextButton addTarget:self action:@selector(RegistNumberView) forControlEvents:UIControlEventTouchUpInside];
        _phoneNumber.backgroundColor = [UIColor colorWithRed:41/255.0 green:187/255.0 blue:207/255.0 alpha:1.0];
        _phoneNumber.textColor = [UIColor whiteColor];
        _phoneNumber.rightViewMode = UITextFieldViewModeAlways;
        _phoneNumber.rightView = nextButton;
    }else{
        NSLog(@"手机号码未通过验证");
        _phoneNumber.rightViewMode = UITextFieldViewModeNever;
        _phoneNumber.backgroundColor = [UIColor whiteColor];
        _phoneNumber.textColor = [UIColor blackColor];
    }
}

-(void)RegistNumberView
{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *rgv = [story instantiateViewControllerWithIdentifier:@"registnumber"];
    [self.navigationController pushViewController:rgv animated:YES];
}

/*邮箱验证 MODIFIED BY HELENSONG*/
-(BOOL)isValidateEmail:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

/*手机号码验证 MODIFIED BY HELENSONG*/
-(BOOL) isValidateMobile:(NSString *)mobile
{
    //手机号以13， 15，18开头，八个 \d 数字字符
    NSString *phoneRegex = @"^((13[0-9])|(15[^4,\\D])|(18[0,0-9]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    //    NSLog(@"phoneTest is %@",phoneTest);
    return [phoneTest evaluateWithObject:mobile];
}

/*车牌号验证 MODIFIED BY HELENSONG*/
BOOL validateCarNo(NSString* carNo)
{
    NSString *carRegex = @"^[A-Za-z]{1}[A-Za-z_0-9]{5}$";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    NSLog(@"carTest is %@",carTest);
    return [carTest evaluateWithObject:carNo];
}

#pragma 取消输入操作
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

#pragma 内存警告，无卵用
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
