//
//  LoginViewController.h
//  ResultContained
//
//  Created by 李胜书 on 15/7/1.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@property (strong,nonatomic) IBOutlet UITextField *userNameText;
@property (strong,nonatomic) IBOutlet UITextField *passWordText;

@property (strong,nonatomic) IBOutlet UIImageView *userNameImage;
@property (strong,nonatomic) IBOutlet UIImageView *passWordImage;

@property (strong,nonatomic) IBOutlet UIButton *thirdLoginButton;

@end
