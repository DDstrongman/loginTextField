//
//  LoginViewController.m
//  ResultContained
//
//  Created by 李胜书 on 15/7/1.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

{
    BOOL isRegisted;//判断是否注册过，注册过则自动填充手机号为账号（仅限为从注册界面跳过来）
    BOOL showPasswordOrNot;//判断是否显示明文密码
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //去登陆界面
    UIButton *registButton = [[UIButton alloc] initWithFrame:CGRectMake(0,2, 30, 30)];
    
    //button1.center = CGPointMake(160, 200);
    registButton.titleLabel.font = [UIFont boldSystemFontOfSize:22];
    [registButton setImage:[UIImage imageNamed:@"test"] forState:UIControlStateNormal];
    
    //button1.displayShading = YES;
    
    [registButton addTarget:self action:@selector(registView) forControlEvents:UIControlEventTouchUpInside];
    
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithCustomView:registButton]];
    
    UIButton *sectureButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    [sectureButton addTarget:self action:@selector(changeSecture) forControlEvents:UIControlEventTouchUpInside];
    [sectureButton setBackgroundImage:[UIImage imageNamed:@"test"] forState:UIControlStateNormal];
    
    _passWordText.rightViewMode = UITextFieldViewModeAlways;
    _passWordText.rightView = sectureButton;
    
    _thirdLoginButton.layer.borderWidth = 1.0;
    _thirdLoginButton.layer.borderColor = [UIColor blueColor].CGColor;
    [_thirdLoginButton.layer setMasksToBounds:YES];
    [_thirdLoginButton.layer setCornerRadius:10.0];
}

-(void)changeSecture{
    if (showPasswordOrNot) {
        _passWordText.secureTextEntry = NO;
        showPasswordOrNot = NO;
    }else{
        _passWordText.secureTextEntry = YES;
        showPasswordOrNot = YES;
    }
}

-(void)registView
{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *lgv = [story instantiateViewControllerWithIdentifier:@"loginAndRegist"];
    [self.navigationController pushViewController:lgv animated:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    //初始化
    [_userNameText becomeFirstResponder];
    _passWordImage.hidden = YES;
    _passWordText.secureTextEntry = YES;
    showPasswordOrNot = YES;
}

-(void)viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBarHidden = YES;
}

-(IBAction)forgotPasswor:(id)sender{
    //加入点击忘记密码的事件
    NSLog(@"忘记密码");
}

-(IBAction)editUserName:(id)sender{
    _userNameImage.hidden = NO;
    _passWordImage.hidden = YES;
}

-(IBAction)editPassword:(id)sender{
    _userNameImage.hidden = YES;
    _passWordImage.hidden = NO;
}

#pragma 取消输入操作
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
