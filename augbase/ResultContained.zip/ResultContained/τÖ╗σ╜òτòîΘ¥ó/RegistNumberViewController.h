//
//  RegistNumberViewController.h
//  ResultContained
//
//  Created by 李胜书 on 15/7/1.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistNumberViewController : UIViewController

//四个输入验证码的textfiled,tag依次为1，2，3，4
@property (strong, nonatomic) IBOutlet UITextField *firstNumber;
@property (strong, nonatomic) IBOutlet UITextField *secondNumber;
@property (strong, nonatomic) IBOutlet UITextField *thirdNumber;
@property (strong, nonatomic) IBOutlet UITextField *forthNumber;


@property (strong, nonatomic) IBOutlet UILabel *countTimeLabel;
@property (strong, nonatomic) IBOutlet UIButton *sendAgainButton;
//@property (strong, nonatomic) IBOutlet UITextField *forthNumber;


@end
