//
//  RegistNumberViewController.m
//  ResultContained
//
//  Created by 李胜书 on 15/7/1.
//  Copyright (c) 2015年 李胜书. All rights reserved.
//

#import "RegistNumberViewController.h"

@interface RegistNumberViewController ()

{
    NSTimer *delayTimer;
    float countTime;
}

@end

@implementation RegistNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    countTime = countAgainNumber;
    delayTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(countNumber) userInfo:nil repeats:YES];
}

-(void)countNumber{
    countTime--;
    _countTimeLabel.text = [NSString stringWithFormat:@"%@%d",@"重发倒计时:",(int)countTime];
    if (countTime == 0) {
        [delayTimer invalidate];
        delayTimer = nil;
        _sendAgainButton.userInteractionEnabled = YES;
        [_sendAgainButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }
}


-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    _sendAgainButton.userInteractionEnabled = NO;
    [_sendAgainButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
}

-(IBAction)inputRegistNumber:(id)sender{
    if ([_firstNumber.text length] == 0) {
        [_firstNumber becomeFirstResponder];
    }else if ([_firstNumber.text length] != 0&&[_secondNumber.text length] == 0){
        [_secondNumber becomeFirstResponder];
    }else if ([_firstNumber.text length] != 0&&[_secondNumber.text length] != 0&&[_thirdNumber.text length] == 0){
        [_thirdNumber becomeFirstResponder];
    }else if ([_firstNumber.text length] != 0&&[_secondNumber.text length] != 0&&[_thirdNumber.text length] != 0&&[_forthNumber.text length] == 0){
        [_forthNumber becomeFirstResponder];
    }else{
        [self.view endEditing:YES];
        //输入完毕，验证验证码是否正确
        NSString *confirmNumber = [_firstNumber.text stringByAppendingFormat:@"%@%@%@",_secondNumber.text,_thirdNumber.text,_forthNumber.text];
        NSLog(@"验证码===%@",confirmNumber);
        UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *ftui = [story instantiateViewControllerWithIdentifier:@"firsttimeuserinfo"];
        [self.navigationController pushViewController:ftui animated:YES];
        
    }
}

#pragma 取消输入操作
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
